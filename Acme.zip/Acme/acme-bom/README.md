# acme-bom

Two artifacts, released together at the same version (2.0.0):

- `acme-bom` — versions of Acme's own libraries (acme-commons 2.0.0, acme-test-support 2.0.0).
- `acme-service-parent` — the parent for deployable services: `acme-parent` + `acme-bom` + container build.

Projects that can't use `acme-service-parent` import `spring-boot-dependencies` and `acme-bom` themselves.

Release after the libraries it lists are released:

```bash
# 1. point the BOM at the new library versions (acme-bom/pom.xml <properties>)
# 2. set the release version everywhere it appears
mvn versions:set -DnewVersion=X.Y.Z -DprocessAllModules=true
mvn versions:set-property -Dproperty=acme-platform.version -DnewVersion=X.Y.Z
# 3. commit, tag vX.Y.Z, push: CI deploys both artifacts
```
