# acme-parent

Build conventions and third-party versions for every Acme library and service.

| Decides | Where |
| --- | --- |
| Spring Boot line | `<parent>` version (currently 4.1.2) |
| Java level | `java.version` (currently 25) |
| Third-party versions Boot doesn't manage | `<properties>` + `<dependencyManagement>` |
| CVE overrides | Boot version properties in `<properties>` |
| Company-wide build checks | `maven-enforcer-plugin` |

Release: `mvn versions:set -DnewVersion=X.Y.Z && mvn -B deploy` (CI deploys on a `vX.Y.Z` tag).

Versioning: MAJOR = new Java baseline or Spring Boot major, MINOR = Spring Boot minor or new convention,
PATCH = Spring Boot patch or CVE override.
