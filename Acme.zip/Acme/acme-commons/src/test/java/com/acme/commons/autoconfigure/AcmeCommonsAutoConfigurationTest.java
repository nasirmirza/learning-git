package com.acme.commons.autoconfigure;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.commons.web.ApiExceptionHandler;
import com.acme.commons.web.CorrelationIdFilter;
import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.AutoConfigurations;
import org.springframework.boot.test.context.runner.ApplicationContextRunner;
import org.springframework.boot.test.context.runner.WebApplicationContextRunner;

class AcmeCommonsAutoConfigurationTest {

    private final WebApplicationContextRunner web = new WebApplicationContextRunner()
            .withConfiguration(AutoConfigurations.of(AcmeCommonsAutoConfiguration.class));

    @Test
    void registersFilterAndHandlerInAServletApp() {
        web.run(context -> {
            assertThat(context).hasSingleBean(CorrelationIdFilter.class);
            assertThat(context).hasSingleBean(ApiExceptionHandler.class);
        });
    }

    @Test
    void backsOffWhenTheServiceDefinesItsOwnFilter() {
        web.withBean("customFilter", CorrelationIdFilter.class, () -> new CorrelationIdFilter("X-Request-Id"))
                .run(context -> assertThat(context).getBeans(CorrelationIdFilter.class).containsOnlyKeys("customFilter"));
    }

    @Test
    void staysOffOutsideAWebApp() {
        new ApplicationContextRunner()
                .withConfiguration(AutoConfigurations.of(AcmeCommonsAutoConfiguration.class))
                .run(context -> assertThat(context).doesNotHaveBean(CorrelationIdFilter.class));
    }
}
