package com.acme.commons.autoconfigure;

import com.acme.commons.web.CorrelationIdFilter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/** Settings under {@code acme.commons.*} in a service's application.yml. */
@ConfigurationProperties(prefix = "acme.commons")
public class AcmeCommonsProperties {

    /** Header that carries the correlation ID between services. */
    private String correlationHeader = CorrelationIdFilter.DEFAULT_HEADER;

    public String getCorrelationHeader() {
        return correlationHeader;
    }

    public void setCorrelationHeader(String correlationHeader) {
        this.correlationHeader = correlationHeader;
    }
}
