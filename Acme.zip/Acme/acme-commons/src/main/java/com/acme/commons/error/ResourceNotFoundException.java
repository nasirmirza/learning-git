package com.acme.commons.error;

/** Throw from any service to get a 404 problem response from {@link com.acme.commons.web.ApiExceptionHandler}. */
public class ResourceNotFoundException extends RuntimeException {

    public ResourceNotFoundException(String message) {
        super(message);
    }
}
