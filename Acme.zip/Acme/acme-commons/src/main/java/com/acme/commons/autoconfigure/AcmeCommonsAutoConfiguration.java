package com.acme.commons.autoconfigure;

import com.acme.commons.web.ApiExceptionHandler;
import com.acme.commons.web.CorrelationIdFilter;
import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.DispatcherServlet;

/**
 * Switched on automatically when a service adds acme-commons (see META-INF/spring/...AutoConfiguration.imports).
 * Every bean backs off if the service defines its own ({@code @ConditionalOnMissingBean}).
 */
@AutoConfiguration
@ConditionalOnWebApplication(type = ConditionalOnWebApplication.Type.SERVLET)
@ConditionalOnClass(DispatcherServlet.class)
@EnableConfigurationProperties(AcmeCommonsProperties.class)
public class AcmeCommonsAutoConfiguration {

    @Bean
    @ConditionalOnMissingBean
    public CorrelationIdFilter correlationIdFilter(AcmeCommonsProperties properties) {
        return new CorrelationIdFilter(properties.getCorrelationHeader());
    }

    @Bean
    @ConditionalOnMissingBean
    public ApiExceptionHandler apiExceptionHandler() {
        return new ApiExceptionHandler();
    }
}
