# acme-commons

Shared runtime library for Acme services: correlation IDs (`X-Correlation-Id`) and RFC 9457 problem
responses, switched on by Spring Boot auto-configuration as soon as a service adds the jar.

Built on `acme-parent` 2.0.0 (Java 25, Spring Boot 4.1.2).
Version 2.0.0 — MAJOR bumps with each platform major, because the jar is compiled for that
line's Java and Spring versions.
