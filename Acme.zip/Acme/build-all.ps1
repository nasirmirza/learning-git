# Builds and installs all seven repos into your local ~/.m2, in release order.
#   .\build-all.ps1          build whatever each repo has checked out
#   .\build-all.ps1 -Line 1  check out platform line 1 (Java 17, Boot 3.5) first  - needs JDK 17+
#   .\build-all.ps1 -Line 2  check out platform line 2 (Java 25, Boot 4.1) first  - needs JDK 25+
param([ValidateSet("", "1", "2")][string]$Line = "")
$ErrorActionPreference = "Stop"
$order = "acme-parent", "acme-commons", "acme-test-support", "acme-bom", "service-a", "service-b", "service-c"
foreach ($repo in $order) {
    if ($Line) {
        $tag = if ($repo -like "service-*") { "on-platform-$Line" } else { "v$Line.0.0" }
        git -C $repo checkout -q $tag
    }
    Write-Host "=== $repo" -ForegroundColor Cyan
    Push-Location $repo
    mvn -B install
    $code = $LASTEXITCODE
    Pop-Location
    if ($code -ne 0) { throw "$repo failed - fix it before building the repos after it" }
}
Write-Host "All repos built." -ForegroundColor Green
