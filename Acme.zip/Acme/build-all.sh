#!/usr/bin/env bash
# Builds and installs all seven repos into your local ~/.m2, in release order.
#   ./build-all.sh      build whatever each repo has checked out
#   ./build-all.sh 1    check out platform line 1 (Java 17, Boot 3.5) first  - needs JDK 17+
#   ./build-all.sh 2    check out platform line 2 (Java 25, Boot 4.1) first  - needs JDK 25+
set -euo pipefail
LINE="${1:-}"
for repo in acme-parent acme-commons acme-test-support acme-bom service-a service-b service-c; do
  if [ -n "$LINE" ]; then
    if [[ $repo == service-* ]]; then tag="on-platform-$LINE"; else tag="v$LINE.0.0"; fi
    git -C "$repo" checkout -q "$tag"
  fi
  echo "=== $repo"
  (cd "$repo" && mvn -B install)
done
echo "All repos built."
