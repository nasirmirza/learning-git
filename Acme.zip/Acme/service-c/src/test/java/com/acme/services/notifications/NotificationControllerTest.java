package com.acme.services.notifications;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import com.acme.commons.error.ResourceNotFoundException;
import com.acme.testsupport.AcmeResultMatchers;
import com.acme.testsupport.AcmeServiceTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

@AcmeServiceTest // from acme-test-support: @SpringBootTest + MockMvc + "test" profile
class NotificationControllerTest {

    @Autowired
    MockMvc mockMvc;

    // @MockitoBean comes from Spring Framework (since 6.2), so it already worked on Boot 3.5.
    @MockitoBean
    NotificationService notificationService;

    @Test
    void returnsTheResourceWithACorrelationId() throws Exception {
        when(notificationService.findById("42")).thenReturn(new Notification("42", "EMAIL", "SENT"));

        mockMvc.perform(get("/notifications/42"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.channel").value("EMAIL"))
                .andExpect(AcmeResultMatchers.correlationIdPresent());
    }

    @Test
    void unknownIdIsAProblemResponse() throws Exception {
        when(notificationService.findById("404")).thenThrow(new ResourceNotFoundException("Notification 404 not found"));

        mockMvc.perform(get("/notifications/404"))
                .andExpect(AcmeResultMatchers.problemDetail(404))
                .andExpect(AcmeResultMatchers.correlationIdPresent());
    }
}
