package com.acme.services.notifications;

import com.acme.commons.error.ResourceNotFoundException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;

@Service
public class NotificationService {

    private final Map<String, Notification> store = new ConcurrentHashMap<>(Map.of("42", new Notification("42", "EMAIL", "SENT")));

    public Notification findById(String id) {
        Notification found = store.get(id);
        if (found == null) {
            // acme-commons turns this into a 404 problem response with the correlation ID.
            throw new ResourceNotFoundException("Notification " + id + " not found");
        }
        return found;
    }
}
