package com.acme.services.notifications;

public record Notification(String id, String channel, String status) {
}
