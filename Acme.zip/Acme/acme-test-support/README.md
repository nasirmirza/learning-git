# acme-test-support

Shared test library: `@AcmeServiceTest` and `AcmeResultMatchers`. Services add it with `<scope>test</scope>`
(acme-bom also manages it as test scope).

It absorbs Spring Boot's test-API churn: in Boot 4, `@AutoConfigureMockMvc` moved package and MockMvc
support moved to `spring-boot-starter-webmvc-test`. Only this library changed; service tests kept
using `@AcmeServiceTest`.
