package com.acme.testsupport;

import static org.assertj.core.api.Assertions.assertThat;

import com.acme.commons.web.CorrelationIdFilter;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.ResultMatcher;

/** Assertions for the platform contract that every service must honour. */
public final class AcmeResultMatchers {

    private AcmeResultMatchers() {
    }

    /** The response carries a correlation ID (set by acme-commons). */
    public static ResultMatcher correlationIdPresent() {
        return result -> assertThat(result.getResponse().getHeader(CorrelationIdFilter.DEFAULT_HEADER))
                .as("response header %s", CorrelationIdFilter.DEFAULT_HEADER)
                .isNotBlank();
    }

    /** The response is an RFC 9457 problem with the given HTTP status. */
    public static ResultMatcher problemDetail(int status) {
        return result -> {
            assertThat(result.getResponse().getStatus()).isEqualTo(status);
            assertThat(MediaType.parseMediaType(result.getResponse().getContentType()))
                    .isEqualTo(MediaType.APPLICATION_PROBLEM_JSON);
        };
    }
}
