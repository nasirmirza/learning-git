package com.acme.services.inventory;

import com.acme.commons.error.ResourceNotFoundException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;

@Service
public class StockLevelService {

    private final Map<String, StockLevel> store = new ConcurrentHashMap<>(Map.of("42", new StockLevel("42", "SKU-7", 15)));

    public StockLevel findById(String id) {
        StockLevel found = store.get(id);
        if (found == null) {
            // acme-commons turns this into a 404 problem response with the correlation ID.
            throw new ResourceNotFoundException("StockLevel " + id + " not found");
        }
        return found;
    }
}
