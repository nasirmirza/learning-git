package com.acme.services.inventory;

public record StockLevel(String id, String sku, int available) {
}
