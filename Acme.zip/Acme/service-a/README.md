# service-a

Deployable Spring Boot service (Orders API). Its only platform setting is the `acme-service-parent`
version in `pom.xml`; Java, Spring Boot and Acme library versions all come from there.

```bash
mvn verify                    # build and test
mvn spring-boot:run           # http://localhost:8080/orders/42
mvn spring-boot:build-image   # container image acme/service-a:1.0.0-SNAPSHOT
```
