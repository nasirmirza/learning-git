package com.acme.services.orders;

public record Order(String id, String item, int quantity) {
}
