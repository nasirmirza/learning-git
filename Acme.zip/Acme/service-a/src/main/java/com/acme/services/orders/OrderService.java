package com.acme.services.orders;

import com.acme.commons.error.ResourceNotFoundException;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import org.springframework.stereotype.Service;

@Service
public class OrderService {

    private final Map<String, Order> store = new ConcurrentHashMap<>(Map.of("42", new Order("42", "Keyboard", 2)));

    public Order findById(String id) {
        Order found = store.get(id);
        if (found == null) {
            // acme-commons turns this into a 404 problem response with the correlation ID.
            throw new ResourceNotFoundException("Order " + id + " not found");
        }
        return found;
    }
}
