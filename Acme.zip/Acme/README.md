# Acme platform example: 7 repositories

Each folder is its own git repository. Build them in this order (each needs the ones before it in ~/.m2):

| # | Repo | Publishes | Depends on |
|---|------|-----------|------------|
| 1 | acme-parent | `acme-parent` (Java level, Spring Boot line, conventions, third-party versions) | spring-boot-starter-parent |
| 2 | acme-commons | `acme-commons` (shared runtime library) | acme-parent |
| 3 | acme-test-support | `acme-test-support` (shared test library) | acme-parent, acme-commons |
| 4 | acme-bom | `acme-bom` (Acme library versions) + `acme-service-parent` | acme-parent, the libraries it lists |
| 5-7 | service-a, service-b, service-c | container images | acme-service-parent |

Every repo has two tagged commits:

| | Platform line 1 (today) | Platform line 2 (after the upgrade) |
|---|---|---|
| Platform repos and libraries | tag `v1.0.0` | tag `v2.0.0` |
| Services | tag `on-platform-1` | tag `on-platform-2` |
| Java / Spring Boot | 17 / 3.5.16 | 25 / 4.1.2 |

```powershell
.\build-all.ps1 -Line 1      # Windows, JDK 17+ (on PATH or JAVA_HOME)
.\build-all.ps1 -Line 2      # Windows, JDK 25+
./build-all.sh 2             # macOS / Linux / Git Bash
git -C service-a diff on-platform-1 on-platform-2   # what a service changes for the upgrade
git -C acme-test-support diff v1.0.0 v2.0.0         # what a library changes
```

`git checkout main` in each repo returns to line 2. The Nexus URLs in `distributionManagement` are placeholders;
`mvn install` only needs your local ~/.m2.
