"""Build the flat SSI import template (v2).

Usage: python build_import_template.py <reference.xlsx> <output.xlsx>
The reference workbook is the one produced by build_reference_data.py.
"""
import sys
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.datavalidation import DataValidation
from openpyxl.utils import get_column_letter

REF, OUT = sys.argv[1], sys.argv[2]
ARIAL = "Arial"
rd = lambda s: pd.read_excel(REF, s, keep_default_na=False, na_values=[''])
comb, rules = rd('Combinations'), rd('Field_Rules')

wb = Workbook()
ins = wb.active; ins.title = "Instructions"
ws = wb.create_sheet("SSI_Import")
ref = wb.create_sheet("Lists")
cs = wb.create_sheet("Combinations")
fl = wb.create_sheet("Field_Labels")

# ---- lookup sheets -------------------------------------------------------
cs.append(["combination_key", "country_code", "security_type_code", "method_code", "pset_bic", "depository_name", "variant"])
for r in comb.itertuples():
    cs.append([r.combination_key, r.country_code, r.security_type_code, r.method_code, r.pset_bic, r.depository_name,
               r.variant if isinstance(r.variant, str) else ""])
n_comb = len(comb) + 1
fl.append(["lookup_key", "combination_key", "slot", "label"])
mid = rules[rules.field_group == 'MARKET_ID']
for r in mid.itertuples():
    lvl = {'MANDATORY': 'mandatory', 'RECOMMENDED': 'recommended', 'OPTIONAL': 'optional',
           'CONDITIONAL': 'conditional'}.get(r.requirement_level, '')
    fl.append([f"{r.combination_key}|{int(r.slot)}", r.combination_key, int(r.slot), f"{r.field_label} ({lvl})" if lvl else r.field_label])
n_fl = len(mid) + 1

LISTS = {
    "A": ("scope_level", ["CLIENT", "FUND", "ACCOUNT"]),
    "B": ("account_type", ["CUSTODY", "LONGBOX", "SEGREGATED", "CASH"]),
    "C": ("platform", ["DOMESTIC", "GLOBAL", "N/A"]),
    "D": ("payment_type", ["ANY", "FOP", "DVP"]),
    "E": ("permitted_direction", ["BOTH", "DELIVER_ONLY", "RECEIVE_ONLY"]),
    "F": ("setr_account_transfer", ["OWNI", "OWNE"]),
    "G": ("yes_no", ["YES", "NO"]),
    "H": ("relationship", ["SUBAGENT"]),
}
for col, (name, vals) in LISTS.items():
    ref[f"{col}1"] = name
    for i, v in enumerate(vals, 2):
        ref[f"{col}{i}"] = v
for s in (ref, cs, fl):
    for c in s[1]:
        c.font = Font(name=ARIAL, bold=True, color="FFFFFF"); c.fill = PatternFill("solid", fgColor="2F6F5E")
    for row in s.iter_rows(min_row=2):
        for c in row: c.font = Font(name=ARIAL, size=10)
    for i in range(1, s.max_column + 1):
        s.column_dimensions[get_column_letter(i)].width = 22
cs.column_dimensions['A'].width = 26; cs.column_dimensions['F'].width = 50
fl.column_dimensions['A'].width = 30; fl.column_dimensions['D'].width = 40

# ---- columns: (name, required, width, kind, help) ------------------------
# kind: in = user input, f = formula (derived, do not type)
C = [
 ("row_ref", 1, 9, "in", "Your own line number, used to report load errors back."),
 ("is_sample", 1, 10, "in", "YES on shipped examples. Delete those rows before loading."),
 ("client_code", 1, 13, "in", "The client this SSI belongs to."),
 ("scope_level", 1, 12, "in", "CLIENT = fallback for all funds. FUND = all accounts of a fund. ACCOUNT = one account."),
 ("fund_lei", 0, 22, "in", "Required for FUND and ACCOUNT scope."),
 ("fund_name", 0, 26, "in", "For checking only. Not matched on."),
 ("account_number", 0, 16, "in", "Required for ACCOUNT scope."),
 ("account_type", 0, 13, "in", "CUSTODY, LONGBOX, SEGREGATED or CASH."),
 ("platform", 0, 10, "in", "DOMESTIC or GLOBAL where the account is platform specific."),
 ("combination_key", 1, 22, "in", "Country-SecurityType-Method from the DTCC catalogue, e.g. US-TRY-FEDWIRE. Pick from the list."),
 ("pset_bic", 0, 13, "f", "Derived from the combination. Do not type."),
 ("depository_name", 0, 30, "f", "Derived from the combination. Do not type."),
 ("payment_type", 1, 12, "in", "ANY unless the chain genuinely differs between FOP and DVP."),
 ("currency_code", 0, 11, "in", "Only for a currency-specific DVP row."),
 ("permitted_direction", 1, 17, "in", "BOTH unless the account may only receive or only deliver."),
 ("local_agent_name", 0, 24, "in", "Participant at the depository."),
 ("local_agent_bic", 0, 16, "in", "Local (sub) agent BIC."),
 ("acct_at_local_agent", 0, 18, "in", "Account of the global custodian AT the local agent."),
 ("custodian_name", 0, 24, "in", "Global custodian, where one sits above the local agent."),
 ("custodian_bic", 0, 16, "in", "Global custodian BIC."),
 ("acct_at_global_custodian", 1, 22, "in", "The account's own safekeeping reference. Becomes :97A::SAFE."),
 ("correspondent_bic", 0, 16, "in", "Intermediary, three levels of clearing only."),
 ("correspondent_sec_acct", 0, 18, "in", "Account at the intermediary."),
 ("relationship", 0, 12, "in", "SUBAGENT when an intermediary is used."),
]
for i in range(1, 6):
    C.append((f"id{i}_label", 0, 24, "f", f"Name of market ID {i} for this combination. Blank means the slot is unused."))
    C.append((f"id{i}_value", 0, 18, "in", f"Value for market ID {i}."))
C += [
 ("registration_name", 0, 20, "in", "Spain (Iberclear) only."),
 ("registration_bic", 0, 16, "in", "Spain (Iberclear) only."),
 ("instructing_party_bic", 0, 18, "in", "T2S markets: BIC of the instructing party."),
 ("setr_deliver", 0, 12, "in", "Default for plain account transfers only (OWNI/OWNE). Event codes come from the event."),
 ("setr_receive", 0, 12, "in", "As above, receive leg."),
 ("cash_currency", 0, 12, "in", "DVP only."),
 ("cash_correspondent_bic", 0, 20, "in", "DVP, split cash settlement only."),
 ("cash_account", 0, 18, "in", "DVP only."),
 ("valid_from", 1, 12, "in", "YYYY-MM-DD, first usable business date."),
 ("valid_to", 0, 12, "in", "YYYY-MM-DD, exclusive. Blank = open ended."),
 ("source_reference", 0, 22, "in", "Where this came from: BNY SSI pack section, ALERT access code, ticket."),
 ("comments", 0, 34, "in", "Carried into the change request for the checker."),
]
names = [c[0] for c in C]
col = {n: get_column_letter(i + 1) for i, n in enumerate(names)}

hdr_req, hdr_opt, hdr_f = (PatternFill("solid", fgColor=x) for x in ("2F6F5E", "8FAFA4", "8A8F8B"))
thin = Side(style="thin", color="C9D2CC"); border = Border(bottom=thin, right=thin)
for i, (n, req, w, kind, h) in enumerate(C, 1):
    c = ws.cell(row=1, column=i, value=n + ("*" if req else ""))
    c.font = Font(name=ARIAL, bold=True, size=10, color="FFFFFF")
    c.fill = hdr_f if kind == "f" else (hdr_req if req else hdr_opt)
    c.alignment = Alignment(wrap_text=True, vertical="center")
    ws.column_dimensions[get_column_letter(i)].width = w
    hc = ws.cell(row=2, column=i, value=h)
    hc.font = Font(name=ARIAL, size=8, italic=True, color="5B655E"); hc.alignment = Alignment(wrap_text=True, vertical="top")
ws.row_dimensions[1].height = 30; ws.row_dimensions[2].height = 64

S = dict
SAMPLES = [
 S(scope_level="ACCOUNT", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", account_number="LONGBOX-001",
   account_type="LONGBOX", platform="DOMESTIC", combination_key="US-TRY-FEDWIRE", payment_type="ANY", permitted_direction="BOTH",
   local_agent_name="BNY (triparty line)", acct_at_global_custodian="LONGBOX-001",
   id1_value="<BNY triparty ABA>", id2_value="<Fed account>", setr_deliver="OWNI", setr_receive="OWNI",
   comments="Treasuries into the longbox. ABA and Fed account from the BNY SSI pack"),
 S(scope_level="ACCOUNT", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", account_number="CUST-88421",
   account_type="CUSTODY", platform="DOMESTIC", combination_key="US-COB-DTC", payment_type="ANY", permitted_direction="BOTH",
   local_agent_name="BNY (custody line)", acct_at_global_custodian="CUST-88421",
   id1_value="<custody DTC participant #>", id2_value="<agent ID>", id3_value="<institution ID>", setr_deliver="OWNI", setr_receive="OWNI",
   comments="Custody participant number differs from the triparty line on the next row"),
 S(scope_level="ACCOUNT", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", account_number="LONGBOX-002",
   account_type="LONGBOX", platform="DOMESTIC", combination_key="US-COB-DTC", payment_type="ANY", permitted_direction="BOTH",
   local_agent_name="BNY (triparty line)", acct_at_global_custodian="LONGBOX-002",
   id1_value="<triparty DTC participant #>", id2_value="<agent ID>", id3_value="<institution ID>", setr_deliver="OWNI", setr_receive="OWNI",
   comments="Different participant number, so custody to triparty moves settle at DTC"),
 S(scope_level="FUND", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", platform="GLOBAL",
   combination_key="EU-COB-EURO_CLEAR", payment_type="ANY", permitted_direction="BOTH", local_agent_name="BNY Mellon SA/NV",
   local_agent_bic="IRVTBEBB", acct_at_global_custodian="<fund account>", id1_value="<Euroclear account #>",
   setr_deliver="OWNI", setr_receive="OWNI", comments="All accounts of the fund unless an ACCOUNT row overrides"),
 S(scope_level="FUND", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", platform="GLOBAL",
   combination_key="EU-COB-CEDEL", payment_type="ANY", permitted_direction="BOTH", local_agent_name="BNY Mellon SA/NV",
   local_agent_bic="IRVTBEBB", acct_at_global_custodian="<fund account>", id1_value="<CEDEL account #>",
   setr_deliver="OWNI", setr_receive="OWNI", comments="Cross-ICSD moves use the Bridge"),
 S(scope_level="ACCOUNT", fund_lei="549300ABCDEF12345678", fund_name="Acme Sterling LDI Fund", account_number="LONGBOX-GB1",
   account_type="LONGBOX", platform="GLOBAL", combination_key="GB-TRY-CREST", payment_type="ANY", permitted_direction="BOTH",
   local_agent_name="BNY London branch", acct_at_local_agent="<account at local agent>", acct_at_global_custodian="LONGBOX-GB1",
   id1_value="<CREST ID>", setr_deliver="OWNI", setr_receive="OWNI", comments="Gilts for LDI collateral"),
 S(scope_level="FUND", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", platform="GLOBAL",
   combination_key="DE-TRY-CLEARGER", payment_type="ANY", permitted_direction="BOTH", local_agent_name="<local sub-custodian>",
   local_agent_bic="<sub-custodian BIC>", acct_at_local_agent="<agent account>", custodian_name="BNY Mellon SA/NV",
   custodian_bic="IRVTBEBB", acct_at_global_custodian="<fund account>", instructing_party_bic="<instructing BIC>",
   setr_deliver="OWNI", setr_receive="OWNI", comments="T2S market: instructing party BIC recommended"),
 S(scope_level="FUND", fund_lei="549300ABCDEF12345678", fund_name="Acme Asia Equity Fund", platform="GLOBAL",
   combination_key="JP-EQU-JASDEC", payment_type="ANY", permitted_direction="BOTH", local_agent_name="<local sub-custodian>",
   local_agent_bic="<sub-custodian BIC>", acct_at_local_agent="<agent account>", custodian_name="BNY London branch",
   custodian_bic="IRVTGB2X", acct_at_global_custodian="<fund account>", id1_value="<JASDEC ID>",
   setr_deliver="OWNI", setr_receive="OWNI", comments="Local agent under a global custodian"),
 S(scope_level="CLIENT", combination_key="US-EQU-DTC", payment_type="ANY", permitted_direction="BOTH",
   local_agent_name="BNY (custody line)", acct_at_global_custodian="<per account>",
   id1_value="<DTC participant #>", id2_value="<agent ID>", id3_value="<institution ID>",
   setr_deliver="OWNI", setr_receive="OWNI", comments="Lowest priority fallback"),
 S(scope_level="ACCOUNT", fund_lei="5493001KJTIIGC8Y1R12", fund_name="Acme Global Bond Fund", account_number="LONGBOX-001",
   account_type="LONGBOX", platform="DOMESTIC", combination_key="US-TRY-FEDWIRE", payment_type="DVP", currency_code="USD",
   permitted_direction="BOTH", local_agent_name="BNY (triparty line)", acct_at_global_custodian="LONGBOX-001",
   id1_value="<BNY triparty ABA>", id2_value="<Fed account>", cash_currency="USD", cash_account="<USD cash account>",
   comments="Only because the cash leg differs. Otherwise the ANY row above covers DVP too"),
]
s_font = Font(name=ARIAL, size=10, italic=True, color="7A6A58"); s_fill = PatternFill("solid", fgColor="FBF4E9")
i_font = Font(name=ARIAL, size=10); i_fill = PatternFill("solid", fgColor="FFFFCC")
f_font = Font(name=ARIAL, size=10, color="5B655E"); f_fill = PatternFill("solid", fgColor="EEF1EC")
LAST = 3 + len(SAMPLES) + 199
K = col["combination_key"]

def formulas(r):
    out = {
      "pset_bic": f'=IF(${K}{r}="","",IFERROR(INDEX(Combinations!$E$2:$E${n_comb},MATCH(${K}{r},Combinations!$A$2:$A${n_comb},0)),"unknown combination"))',
      "depository_name": f'=IF(${K}{r}="","",IFERROR(INDEX(Combinations!$F$2:$F${n_comb},MATCH(${K}{r},Combinations!$A$2:$A${n_comb},0)),""))',
    }
    for i in range(1, 6):
        out[f"id{i}_label"] = (f'=IF(${K}{r}="","",IFERROR(INDEX(Field_Labels!$D$2:$D${n_fl},'
                               f'MATCH(${K}{r}&"|{i}",Field_Labels!$A$2:$A${n_fl},0)),""))')
    return out

for r in range(3, LAST + 1):
    sample = SAMPLES[r - 3] if r - 3 < len(SAMPLES) else None
    f = formulas(r)
    for i, (n, req, w, kind, h) in enumerate(C, 1):
        c = ws.cell(row=r, column=i); c.border = border
        if kind == "f":
            c.value = f[n]; c.font = f_font; c.fill = f_fill
        elif sample is not None:
            if n == "row_ref": c.value = r - 2
            elif n == "is_sample": c.value = "YES"
            elif n == "client_code": c.value = "ACME-AM"
            elif n == "valid_from": c.value = "2026-12-01"
            elif n == "source_reference": c.value = "BNY SSI pack"
            else: c.value = sample.get(n, None)
            c.font = s_font; c.fill = s_fill
        else:
            c.font = i_font; c.fill = i_fill

def dv(colname, formula):
    v = DataValidation(type="list", formula1=formula, allow_blank=True)
    ws.add_data_validation(v); v.add(f"{col[colname]}3:{col[colname]}{LAST}")
dv("combination_key", f"=Combinations!$A$2:$A${n_comb}")
for colname, lc in [("scope_level", "A"), ("account_type", "B"), ("platform", "C"), ("payment_type", "D"),
                    ("permitted_direction", "E"), ("setr_deliver", "F"), ("setr_receive", "F"), ("is_sample", "G"), ("relationship", "H")]:
    n = len(LISTS[lc][1]) + 1
    dv(colname, f"=Lists!${lc}$2:${lc}${n}")
ws.freeze_panes = "D3"
ws.auto_filter.ref = f"A1:{get_column_letter(len(C))}1"

# ---- instructions --------------------------------------------------------
ins.column_dimensions["A"].width = 3; ins.column_dimensions["B"].width = 108
text = [
 ("H1", "SSI import template, version 2"),
 ("P", "One row per settlement chain. The loader creates an ssi_key and its first ssi_version per row and raises "
       "one change request per row for maker-checker approval. Nothing is active until a checker approves it."),
 ("H2", "Filling it in"),
 ("B", "Work on SSI_Import. Row 1 is the header, row 2 is guidance, then shipped examples tinted cream with is_sample = YES. Delete the examples before loading."),
 ("B", "Type into yellow cells only. Grey cells are formulas that look up the DTCC catalogue; do not overwrite them."),
 ("B", "Columns marked * are mandatory. Angle-bracket values are placeholders to replace from your BNY SSI pack or custodian."),
 ("H2", "Choosing the market"),
 ("B", "Pick combination_key from the list. It is the DTCC country, security type and method in one value, for example US-TRY-FEDWIRE. "
       "Only combinations in the DTCC catalogue are offered, so invalid pairings cannot be entered."),
 ("B", "pset_bic and depository_name fill in automatically. id1_label to id5_label show which market IDs this combination needs and how strictly. "
       "Fill the matching idN_value. A blank label means the slot is not used."),
 ("H2", "One row covers both directions"),
 ("B", "The chain is the same whether securities arrive or leave, so do not add separate deliver and receive rows. "
       "Use permitted_direction for one-way accounts, and the cash columns only where the cash leg genuinely differs."),
 ("B", "setr_deliver and setr_receive are defaults for plain account transfers only (OWNI one servicer, OWNE across servicers). "
       "Lending, repo, collateral and trade codes come from the business event at message time, not from the SSI."),
 ("H2", "How rows resolve"),
 ("B", "ACCOUNT beats FUND beats CLIENT; an exact currency beats a blank one. If two rows tie for the same key and dates, the load is rejected."),
 ("H2", "Dates"),
 ("B", "valid_from is the first usable business date. valid_to is exclusive. Two active rows for the same key may not overlap."),
 ("H2", "Legend"),
 ("B", "Dark green header: mandatory. Pale green: optional. Grey header and cells: derived by formula. Yellow: your input. Cream italic: examples."),
]
r = 2
for kind, t in text:
    c = ins.cell(row=r, column=2, value=t)
    if kind == "H1": c.font = Font(name=ARIAL, bold=True, size=16)
    elif kind == "H2": c.font = Font(name=ARIAL, bold=True, size=11, color="2F6F5E")
    else:
        c.font = Font(name=ARIAL, size=10, italic=(kind == "P")); c.alignment = Alignment(wrap_text=True, vertical="top")
        ins.row_dimensions[r].height = 15 + 13 * (len(t) // 105)
    r += 2 if kind in ("H1", "P") else 1
wb.save(OUT)
print("written", OUT, "samples", len(SAMPLES), "rows to", LAST)
