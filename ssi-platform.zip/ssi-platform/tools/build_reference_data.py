import sys, re, json, datetime
import pandas as pd

SRC, OUT = sys.argv[1], sys.argv[2]
df = pd.read_excel(SRC, sheet_name='Markets', keep_default_na=False, na_values=[''])
df.columns = [c.replace('ⓘ\n', '').replace('\n', ' ').strip() for c in df.columns]
df = df.dropna(how='all').copy()
raw = df.copy()
for c in df.columns:
    if c != 'Date Updated':
        df[c] = df[c].apply(lambda v: v.strip() if isinstance(v, str) else v)
df['Date Updated'] = pd.to_datetime(df['Date Updated']).dt.date

PUB = {'publication_code': 'AL996', 'title': 'Market Business Rules for Investment Managers',
       'publication_date': '2025-10-29'}

# ---------- countries ----------
name_override = {'CN': 'China', 'EU': 'Europe (ICSDs)'}
countries = (df.groupby('ISO Code')['Country']
             .agg(lambda s: s.value_counts().index[0]).reset_index())
countries.columns = ['country_code', 'country_name']
countries['country_name'] = countries.apply(lambda r: name_override.get(r.country_code, r.country_name), axis=1)
countries['is_pseudo_country'] = countries['country_code'].eq('EU').map({True: 'Y', False: 'N'})
countries['combination_count'] = countries['country_code'].map(df['ISO Code'].value_counts())
countries = countries.sort_values('country_name').reset_index(drop=True)

# ---------- security types ----------
st_meta = {
 'EQU': ('Equity', 'STANDARD', None, 'DTCC recommends EQU, COB and TRY as the minimum set for each market'),
 'COB': ('Fixed income (corporate bonds)', 'STANDARD', None, 'DTCC recommends EQU, COB and TRY as the minimum set for each market'),
 'TRY': ('Government bonds', 'STANDARD', None, 'DTCC recommends EQU, COB and TRY as the minimum set for each market'),
 'MMT': ('Money market', 'STANDARD', None, ''),
 'MBS': ('Mortgage-backed securities', 'SPECIALIST', 'COB', 'US Fedwire only in this file'),
 'TBI': ('Treasury bills', 'SPECIALIST', 'TRY', 'Egypt only in this file'),
 'EQA': ('Equity, alternate', 'ALTERNATE', 'EQU', 'Alternate type used where a market needs a second instruction (CN, IN, TW, TH)'),
 'CBA': ('Fixed income, alternate', 'ALTERNATE', 'COB', 'Alternate type used where a market needs a second instruction'),
 'TRA': ('Government bonds, alternate', 'ALTERNATE', 'TRY', 'Alternate type used where a market needs a second instruction'),
 'MMA': ('Money market, alternate', 'ALTERNATE', 'MMT', 'Alternate type used where a market needs a second instruction'),
 'NSD': ('Not described in this file', 'UNCONFIRMED', None, 'Used only with CMU (CN, HK). Confirm in DTCC "SSI Securities and Security Type Groups"'),
}
sts = df['Security Type'].value_counts().rename_axis('security_type_code').reset_index(name='combination_count')
sts['description'] = sts.security_type_code.map(lambda c: st_meta.get(c, ('?',))[0])
sts['category'] = sts.security_type_code.map(lambda c: st_meta.get(c, ('', 'UNCONFIRMED'))[1])
sts['rolls_up_to'] = sts.security_type_code.map(lambda c: st_meta.get(c, ('', '', None))[2])
sts['note'] = sts.security_type_code.map(lambda c: st_meta.get(c, ('', '', None, ''))[3])
sts['description_source'] = sts.category.map(lambda c: 'DTCC guidance text' if c == 'STANDARD' else 'Inferred from guidance text, confirm with DTCC')
order = {'STANDARD': 0, 'SPECIALIST': 1, 'ALTERNATE': 2, 'UNCONFIRMED': 3}
sts = sts.sort_values(['category', 'combination_count'], key=lambda s: s.map(order) if s.name == 'category' else -s).reset_index(drop=True)

# ---------- methods ----------
meth = (df.groupby('Method').agg(
    depository_name=('Method/Depository Description', 'first'),
    pset_bic=('PSET BIC', 'first'),
    countries=('ISO Code', lambda s: ', '.join(sorted(s.unique()))),
    combination_count=('ISO Code', 'size')).reset_index())
meth.columns = ['method_code'] + list(meth.columns[1:])
meth['pset_bic11'] = meth.pset_bic.map(lambda b: b if len(b) == 11 else b + 'XXX')
meth['spans_countries'] = meth.countries.str.contains(',').map({True: 'Y', False: 'N'})
meth = meth.sort_values('method_code').reset_index(drop=True)

# ---------- combinations ----------
pair_n = df.groupby(['ISO Code', 'Security Type'])['Method'].transform('nunique')
def variant(r):
    m, st, g = r['Method'], r['Security Type'], str(r['Guidance'] or '')
    if 'T2S' in m: return 'T2S settlement'
    if m.endswith('SBI'): return 'Local regime variant (SBI / SLAB)'
    if st in ('EQA', 'CBA', 'TRA', 'MMA'): return 'Alternate security type'
    if 'Stock Connect' in g: return 'Stock Connect'
    if 'BOND CONNECT' in g.upper() or 'CIBM' in g.upper(): return 'Bond Connect / CIBM'
    return ''
def short(g, n=220):
    g = re.sub(r'\s+', ' ', str(g or '')).strip()
    return g if len(g) <= n else g[:n].rsplit(' ', 1)[0] + ' ...'
comb = pd.DataFrame({
    'country_code': df['ISO Code'], 'security_type_code': df['Security Type'], 'method_code': df['Method'],
    'pset_bic': df['PSET BIC'], 'depository_name': df['Method/Depository Description'],
})
comb['methods_for_country_sectype'] = pair_n.values
comb['user_must_choose_method'] = comb.methods_for_country_sectype.gt(1).map({True: 'Y', False: 'N'})
comb['variant'] = df.apply(variant, axis=1).values
comb['tenant_default'] = ''
comb['t2s_institution_field'] = df['Institution/Executing Broker Data Requirement'].notna().map({True: 'Y', False: 'N'}).values
comb['dtcc_guidance_short'] = df['Guidance'].map(short).values
comb['dtcc_guidance_full'] = df['Guidance'].map(lambda g: re.sub(r'[ \t]+', ' ', str(g or '')).strip()).values
comb['dtcc_date_updated'] = df['Date Updated'].astype(str).values
comb['dtcc_publication'] = PUB['publication_code']
comb = comb.sort_values(['country_code', 'security_type_code', 'method_code']).reset_index(drop=True)
comb.insert(0, 'combination_id', range(1, len(comb) + 1))
comb.insert(1, 'combination_key', comb.country_code + '-' + comb.security_type_code + '-' + comb.method_code)

cascade = (comb.groupby(['country_code', 'security_type_code'])
           .agg(method_count=('method_code', 'size'),
                methods=('method_code', lambda s: ', '.join(s)),
                variants=('variant', lambda s: ', '.join(sorted({v for v in s if v}))))
           .reset_index())
cascade['ui_behaviour'] = cascade.method_count.map(lambda n: 'Auto-fill method, read only' if n == 1 else 'User chooses; show variant and guidance')
cascade['tenant_default_method'] = ''

# ---------- field rules ----------
def level(t):
    if not isinstance(t, str) or not t.strip(): return None
    s = t.lower()
    if s in ('n/a', 'na'): return 'NOT_APPLICABLE'
    if 'not allowed' in s: return 'CONDITIONAL'
    if re.search(r'\b(when|if|unless)\b', s) or s.startswith('conditional') or 'only' in s: return 'CONDITIONAL'
    if s.startswith('mandatory') or s == 'required': return 'MANDATORY'
    if s.startswith('recommended'): return 'RECOMMENDED'
    if s.startswith('optional'): return 'OPTIONAL'
    return 'CONDITIONAL'

CHAIN = [
 # field_code, label, desc col, req col, chain role, typical MT54x placement
 ('ACCT_AT_GLOBAL_CUSTODIAN', 'A/C# @ Global Custodian', 'A/C# @ Global Custodian', 'A/C# @ Global Custodian Requirement', 'ACCOUNT_OWNER', ':97A::SAFE in the BUYR/SELL block'),
 ('CUSTODIAN_BIC', 'Custodian BIC', 'Custodian BIC', 'Custodian BIC Requirement', 'GLOBAL_CUSTODIAN', ':95P::BUYR or SELL'),
 ('ACCT_AT_LOCAL_AGENT', 'A/C# @ Local Agent', 'A/C# @ Local Agent', 'A/C# @ Local Agent Requirement', 'LOCAL_AGENT', ':97A::SAFE in the REAG/DEAG block'),
 ('LOCAL_AGENT_BIC', 'Local Agent BIC (sub agent)', 'Local Agent BIC', 'Local Agent BIC Requirement', 'LOCAL_AGENT', ':95P::REAG or DEAG'),
 ('CORRESP_SEC_ACCT', 'Correspondent Security A/C#', 'Correspondent Security A/C#', 'Correspondent Security A/C# Requirement', 'INTERMEDIARY', ':97A::SAFE in the RECU/DECU block'),
 ('CORRESP_BIC', 'Correspondent BIC', 'Correspondent BIC', 'Correspondent BIC Requirement', 'INTERMEDIARY', ':95P::RECU or DECU'),
 ('RELATIONSHIP', 'Relationship', 'Relationship', 'Relationship Requirement', 'INTERMEDIARY', 'ALERT setting (SUBAGENT for three levels)'),
 ('REGISTRATION_NAME', 'Registration Name', 'Registration Name', 'Registration Name Requirement', 'REGISTRATION', 'Registration details (Spain)'),
 ('REGISTRATION_BIC', 'Registration BIC', 'Registration BIC', 'Registration BIC Requirement', 'REGISTRATION', 'Registration details (Spain)'),
 ('INSTRUCTING_PARTY_BIC', 'Institution/Executing Broker Data', 'Institution/Executing Broker Data', 'Institution/Executing Broker Data Requirement', 'INSTRUCTING_PARTY', 'T2S additional party data'),
]
rows = []
key_of = dict(zip(zip(df['ISO Code'], df['Security Type'], df['Method']), [None]*len(df)))
cid = {(r.country_code, r.security_type_code, r.method_code): r.combination_id for r in comb.itertuples()}
for _, r in df.iterrows():
    k = (r['ISO Code'], r['Security Type'], r['Method'])
    base = {'combination_id': cid[k], 'combination_key': '-'.join(k)}
    for i in range(1, 6):
        nm = r.get(f'(ID{i}) - Name')
        if isinstance(nm, str) and nm.strip() and nm.strip().upper() not in ('N/A', 'NA'):
            req = r.get(f'(ID{i}) - Requirement')
            rows.append({**base, 'field_group': 'MARKET_ID', 'slot': i, 'field_code': f'ID{i}',
                         'field_label': nm.strip(),
                         'chain_role': 'LOCAL_AGENT' if nm.strip().startswith('A/C# @ Depository') else 'MARKET_IDENTIFIER',
                         'mt54x_placement': ':95R:: REAG/DEAG with the depository scheme' if nm.strip().startswith('A/C# @ Depository') else 'Market-specific, confirm per market',
                         'description': short(r.get(f'(ID{i}) - Description'), 400),
                         'requirement_level': level(req), 'requirement_text': short(req, 600),
                         'format_text': short(r.get(f'(ID{i}) - Format'), 600)})
    for code, label, dcol, rcol, role, place in CHAIN:
        req = r.get(rcol)
        if isinstance(req, str) and req.strip():
            rows.append({**base, 'field_group': 'CHAIN', 'slot': None, 'field_code': code, 'field_label': label,
                         'chain_role': role, 'mt54x_placement': place,
                         'description': short(r.get(dcol), 400),
                         'requirement_level': level(req), 'requirement_text': short(req, 600), 'format_text': ''})
rules = pd.DataFrame(rows).sort_values(['combination_id', 'field_group', 'slot', 'field_code'], na_position='last')
rules.insert(0, 'rule_id', range(1, len(rules) + 1))

# ---------- data quality ----------
dq = []
ws = [(c, v) for c in ['Country', 'Method'] for v in raw[c].dropna().unique() if isinstance(v, str) and v != v.strip()]
for c, v in ws: dq.append(('Trailing whitespace', c, repr(v), 'Trimmed on load'))
for _, r in df[(df.Country == 'Hong Kong') & (df['ISO Code'] == 'CN')].iterrows():
    dq.append(('Country name differs from ISO code', 'Country', f"Hong Kong / CN / {r['Security Type']} / {r['Method']}",
               'Stock Connect northbound rows: settlement country is CN. Keyed on ISO code; name taken as China'))
dq.append(('Pseudo country code', 'ISO Code', 'EU', 'DTCC uses EU (Europe) for ICSD instructions; not an ISO 3166 country. Kept as is'))
dq.append(('BIC length mix', 'PSET BIC', f"{(df['PSET BIC'].str.len()==8).sum()} BIC8 / {(df['PSET BIC'].str.len()==11).sum()} BIC11",
           'Published form kept in pset_bic; pset_bic11 adds XXX for comparison. SEGA (INSECHZZ) and SEGAT2S (INSECHZZXXX) differ only by this'))
for i in (2, 3):
    n = (df[f'(ID{i}) - Name'].astype(str).str.strip() == f'ID{i}').sum()
    if n: dq.append(('Placeholder field name', f'(ID{i}) - Name', f'"ID{i}" on {n} rows', 'Label not provided by DTCC; show generic label'))
dq.append(('Free-text requirements', 'Requirement columns', 'Conditional rules written as prose',
           'Classified into requirement_level; requirement_text kept verbatim. Conditional rules need a rule author to codify'))
dq.append(('Incomplete security type list', 'Guidance', 'Guidance mentions GDR, ADR, TBA and more',
           'This file covers group-level types only; granular types are in the DTCC "SSI Securities and Security Type Groups" document'))
dq.append(('Header typo', 'Particpant', 'Column header spelling', 'Mapped by position, not name, on future loads'))
dq = pd.DataFrame(dq, columns=['issue', 'column', 'detail', 'handling'])

# ---------- write xlsx ----------
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
xl = OUT + '/SSI_market_reference_DTCC_AL996.xlsx'
with pd.ExcelWriter(xl, engine='openpyxl') as w:
    pd.DataFrame().to_excel(w, sheet_name='README', index=False)
    for name, d in [('Countries', countries), ('Security_Types', sts), ('Methods', meth),
                    ('Combinations', comb.drop(columns=['dtcc_guidance_full'])), ('Cascade', cascade),
                    ('Field_Rules', rules), ('Guidance_Full', comb[['combination_id', 'combination_key', 'dtcc_guidance_full']]),
                    ('Data_Quality', dq)]:
        d.to_excel(w, sheet_name=name, index=False)
from openpyxl import load_workbook
wb = load_workbook(xl)
hdr_fill = PatternFill('solid', fgColor='2F6F5E')
for ws_ in wb.worksheets:
    for row in ws_.iter_rows():
        for c in row: c.font = Font(name='Arial', size=10)
    if ws_.title == 'README': continue
    for c in ws_[1]:
        c.font = Font(name='Arial', size=10, bold=True, color='FFFFFF'); c.fill = hdr_fill
        c.alignment = Alignment(wrap_text=True, vertical='center')
    ws_.freeze_panes = 'A2'; ws_.auto_filter.ref = ws_.dimensions
    for i, col in enumerate(ws_.columns, 1):
        width = max(len(str(c.value)) if c.value is not None else 0 for c in list(col)[:200])
        ws_.column_dimensions[get_column_letter(i)].width = min(max(10, width + 2), 60)
rd = wb['README']; rd.column_dimensions['A'].width = 24; rd.column_dimensions['B'].width = 110
lines = [
 ('SSI market reference data', ''),
 ('Source', f"DTCC {PUB['title']}, publication {PUB['publication_code']}, dated {PUB['publication_date']}"),
 ('Built', datetime.date.today().isoformat()),
 ('', ''),
 ('Countries', f'{len(countries)} settlement countries, keyed on ISO code. EU is DTCC\'s pseudo country for the ICSDs.'),
 ('Security_Types', f'{len(sts)} codes. EQU, COB, TRY, MMT are standard; alternates roll up to a standard type.'),
 ('Methods', f'{len(meth)} methods (depositories). Each method has exactly one PSET BIC, so PSET is derived, never chosen.'),
 ('Combinations', f'{len(comb)} valid country / security type / method combinations. This is the dropdown source.'),
 ('Cascade', f'{len(cascade)} country + security type pairs: {(cascade.method_count==1).sum()} have one method (auto-fill), {(cascade.method_count>1).sum()} need a choice.'),
 ('Field_Rules', f'{len(rules)} rows: which fields each combination needs, at what level, with DTCC wording kept verbatim.'),
 ('Guidance_Full', 'Full DTCC guidance text per combination, for the help panel.'),
 ('Data_Quality', 'Issues found in the source and how they were handled.'),
 ('', ''),
 ('Columns to complete', 'Combinations.tenant_default and Cascade.tenant_default_method are left blank on purpose: '
                         'DTCC publishes no default in this file, so your operations team decides per tenant.'),
 ('Inferred values', 'Security type descriptions other than EQU, COB, TRY, MMT and the chain_role / mt54x_placement columns '
                     'are interpretations. Confirm them before go-live.'),
]
for i, (a, b) in enumerate(lines, 1):
    rd.cell(row=i, column=1, value=a).font = Font(name='Arial', size=10 if i > 1 else 14, bold=True)
    rd.cell(row=i, column=2, value=b).alignment = Alignment(wrap_text=True)
wb.save(xl)

# ---------- json cascade for the UI ----------
tree = {'source': PUB, 'countries': []}
for cc in countries.itertuples():
    sub = comb[comb.country_code == cc.country_code]
    tree['countries'].append({
        'code': cc.country_code, 'name': cc.country_name,
        'securityTypes': [{
            'code': st, 'description': st_meta.get(st, ('?',))[0],
            'methods': [{'combinationId': int(m.combination_id), 'code': m.method_code, 'psetBic': m.pset_bic,
                         'depository': m.depository_name, 'variant': m.variant or None,
                         'guidance': m.dtcc_guidance_short or None} for m in g.itertuples()]
        } for st, g in sub.groupby('security_type_code', sort=False)]})
json.dump(tree, open(OUT + '/ssi_market_cascade.json', 'w'), indent=1, ensure_ascii=False)

# ---------- oracle sql ----------
def q(v):
    if v is None or (isinstance(v, float) and pd.isna(v)) or v == '': return 'NULL'
    return "'" + str(v).replace("'", "''") + "'"
L = ['-- SSI market reference data loaded from DTCC ' + PUB['publication_code'] + ' (' + PUB['publication_date'] + ')',
     '-- Generated ' + datetime.date.today().isoformat() + '. Run in a staging schema first.', '',
'''CREATE TABLE ref_publication (
  publication_code VARCHAR2(16) PRIMARY KEY,
  title            VARCHAR2(200),
  publication_date DATE,
  loaded_at        TIMESTAMP WITH TIME ZONE DEFAULT SYSTIMESTAMP
);

CREATE TABLE ref_country (
  country_code      CHAR(2) PRIMARY KEY,
  country_name      VARCHAR2(80) NOT NULL,
  is_pseudo_country CHAR(1) DEFAULT 'N' NOT NULL CHECK (is_pseudo_country IN ('Y','N'))
);

CREATE TABLE ref_security_type (
  security_type_code VARCHAR2(8) PRIMARY KEY,
  description        VARCHAR2(80) NOT NULL,
  category           VARCHAR2(16) NOT NULL,   -- STANDARD | SPECIALIST | ALTERNATE | UNCONFIRMED
  rolls_up_to        VARCHAR2(8) REFERENCES ref_security_type
);

CREATE TABLE ref_method (
  method_code     VARCHAR2(16) PRIMARY KEY,
  depository_name VARCHAR2(140) NOT NULL,
  pset_bic        VARCHAR2(11) NOT NULL,
  pset_bic11      CHAR(11) NOT NULL
);

CREATE TABLE ref_market_combination (
  combination_id     NUMBER PRIMARY KEY,
  country_code       CHAR(2)      NOT NULL REFERENCES ref_country,
  security_type_code VARCHAR2(8)  NOT NULL REFERENCES ref_security_type,
  method_code        VARCHAR2(16) NOT NULL REFERENCES ref_method,
  variant            VARCHAR2(60),
  guidance           CLOB,
  dtcc_date_updated  DATE,
  publication_code   VARCHAR2(16) REFERENCES ref_publication,
  status             VARCHAR2(12) DEFAULT 'ACTIVE' NOT NULL,   -- ACTIVE | WITHDRAWN
  CONSTRAINT uq_market_comb UNIQUE (country_code, security_type_code, method_code)
);

CREATE TABLE ref_field_rule (
  rule_id           NUMBER PRIMARY KEY,
  combination_id    NUMBER NOT NULL REFERENCES ref_market_combination,
  field_group       VARCHAR2(12) NOT NULL,   -- MARKET_ID | CHAIN
  slot              NUMBER(1),
  field_code        VARCHAR2(32) NOT NULL,
  field_label       VARCHAR2(80) NOT NULL,
  chain_role        VARCHAR2(24),
  requirement_level VARCHAR2(16) NOT NULL,   -- MANDATORY | RECOMMENDED | OPTIONAL | CONDITIONAL | NOT_APPLICABLE
  requirement_text  VARCHAR2(1000),
  format_text       VARCHAR2(1000),
  validation_regex  VARCHAR2(400),           -- authored by your team, not by DTCC
  condition_expr    VARCHAR2(1000),          -- codified version of a CONDITIONAL rule
  CONSTRAINT uq_field_rule UNIQUE (combination_id, field_code)
);

-- Tenant layer: which combinations a tenant offers, and its default where DTCC allows several
CREATE TABLE tenant_market_combination (
  tenant_id      NUMBER NOT NULL,
  combination_id NUMBER NOT NULL REFERENCES ref_market_combination,
  enabled        CHAR(1) DEFAULT 'Y' NOT NULL CHECK (enabled IN ('Y','N')),
  is_default     CHAR(1) DEFAULT 'N' NOT NULL CHECK (is_default IN ('Y','N')),
  CONSTRAINT pk_tenant_mc PRIMARY KEY (tenant_id, combination_id)
);
''',
     "INSERT INTO ref_publication (publication_code, title, publication_date) VALUES ("
     f"{q(PUB['publication_code'])}, {q(PUB['title'])}, DATE '{PUB['publication_date']}');", '']
for r in countries.itertuples():
    L.append(f"INSERT INTO ref_country VALUES ({q(r.country_code)}, {q(r.country_name)}, {q(r.is_pseudo_country)});")
L.append('')
for r in sorted(sts.itertuples(), key=lambda r: r.rolls_up_to is not None):
    L.append(f"INSERT INTO ref_security_type VALUES ({q(r.security_type_code)}, {q(r.description)}, {q(r.category)}, {q(r.rolls_up_to)});")
L.append('')
for r in meth.itertuples():
    L.append(f"INSERT INTO ref_method VALUES ({q(r.method_code)}, {q(r.depository_name)}, {q(r.pset_bic)}, {q(r.pset_bic11)});")
L.append('')
for r in comb.itertuples():
    L.append("INSERT INTO ref_market_combination (combination_id, country_code, security_type_code, method_code, variant, guidance, dtcc_date_updated, publication_code) VALUES ("
             f"{r.combination_id}, {q(r.country_code)}, {q(r.security_type_code)}, {q(r.method_code)}, {q(r.variant)}, {q(r.dtcc_guidance_short)}, DATE '{r.dtcc_date_updated}', {q(r.dtcc_publication)});")
L.append('')
for r in rules.itertuples():
    slot = 'NULL' if pd.isna(r.slot) else int(r.slot)
    L.append("INSERT INTO ref_field_rule (rule_id, combination_id, field_group, slot, field_code, field_label, chain_role, requirement_level, requirement_text, format_text) VALUES ("
             f"{r.rule_id}, {r.combination_id}, {q(r.field_group)}, {slot}, {q(r.field_code)}, {q(r.field_label[:80])}, {q(r.chain_role)}, {q(r.requirement_level)}, {q(str(r.requirement_text)[:1000])}, {q(str(r.format_text)[:1000])});")
L += ['', 'COMMIT;']
open(OUT + '/ssi_market_reference_oracle.sql', 'w').write('\n'.join(L))

print(json.dumps({'countries': len(countries), 'security_types': len(sts), 'methods': len(meth),
                  'combinations': len(comb), 'pairs': len(cascade), 'single': int((cascade.method_count == 1).sum()),
                  'multi': int((cascade.method_count > 1).sum()), 'field_rules': len(rules),
                  'levels': rules.requirement_level.value_counts().to_dict(),
                  'variants': comb.variant.value_counts().to_dict(), 'dq': len(dq)}, indent=1))
