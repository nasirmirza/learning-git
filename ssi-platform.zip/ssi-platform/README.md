# SSI Platform

Design and starter artifacts for an application that sets up, approves and uses
standing settlement instructions (SSIs) for custody, triparty and collateral
products. Built around BNY triparty and CollateralONE flows and the DTCC
market business rules.

Start with **[docs/index.html](docs/index.html)**: the full design document,
with the domain background in part I and the application design in part II.

## Contents

| Path | What it is |
|---|---|
| `docs/index.html` | Design document: domain background, architecture, data model, screens, workflows, resolver, message generation, validation, security, API, delivery plan |
| `docs/reference-notes.html` | Detailed domain notes: MT540 to MT548, triparty mechanics, depository settlement, clients and funds, DTCC ALERT, transaction types |
| `db/01_reference_schema_and_data.sql` | Reference tables plus the DTCC AL996 catalogue: 119 countries, 11 security types, 173 methods, 503 combinations, 5,277 field rules |
| `db/02_core_schema.sql` | Core schema: tenancy, parties, accounts, participant accounts, SSI key and versions, chain, market identifiers, cash, mappings, maker-checker |
| `db/03_ssi_pkg.sql` | PL/SQL package: the only write path, approval with overlap check, and the resolver |
| `reference-data/SSI_market_reference_DTCC_AL996.xlsx` | Reference data for review and sign-off |
| `reference-data/ssi_market_cascade.json` | Country, security type and method tree for the UI cascade |
| `templates/SSI_import_template_v2.xlsx` | Bulk import template: combination dropdown, PSET and market ID labels looked up by formula |
| `tools/build_reference_data.py` | Rebuilds reference data, JSON and SQL from a new DTCC edition |
| `tools/build_import_template.py` | Rebuilds the import template from the reference workbook |

## Database setup (Oracle 19c or later)

Run in order, in a staging schema first:

```sql
@db/01_reference_schema_and_data.sql
@db/02_core_schema.sql
@db/03_ssi_pkg.sql
```

Grant the application `EXECUTE` on `ssi_pkg` and no DML on the tables. The
Flashback archive and VPD statements at the end of `02_core_schema.sql` are
commented out because they need DBA privileges.

## Refreshing the DTCC catalogue

```bash
python tools/build_reference_data.py <dtcc_market_rules.xlsx> <output_dir>
python tools/build_import_template.py <output_dir>/SSI_market_reference_DTCC_AL996.xlsx templates/SSI_import_template_v2.xlsx
```

The loader keeps literal codes (Namibia is `NA`), trims whitespace, keys
countries on ISO code, and records data quality issues in the workbook.
Requires Python 3 with `pandas` and `openpyxl`.

## Status and caveats

- Design for review. The SQL parses with an Oracle-dialect parser but has not
  been compiled against a database; the package needs unit tests before use.
- Security type descriptions beyond EQU, COB, TRY and MMT, and the chain-role
  and MT placement columns in the field rules, are interpretations to confirm
  against DTCC and BNY documentation.
- Identifiers in examples and templates are illustrative placeholders.
- The reference data derives from a DTCC publication marked all rights
  reserved and includes its guidance text. Keep this repository private, or
  strip the guidance columns before sharing outside the firm.
