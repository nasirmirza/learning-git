-- =====================================================================
-- ssi_pkg: the only write path for SSIs, plus the resolver.
-- Grant EXECUTE on this package to the application; grant no DML on tables.
-- Status: written for review, not yet compiled against a live database.
-- =====================================================================
CREATE OR REPLACE PACKAGE ssi_pkg AS

  e_overlap   EXCEPTION; PRAGMA EXCEPTION_INIT(e_overlap,  -20010);
  e_ambiguous EXCEPTION; PRAGMA EXCEPTION_INIT(e_ambiguous,-20020);
  e_not_found EXCEPTION; PRAGMA EXCEPTION_INIT(e_not_found,-20030);
  e_four_eyes EXCEPTION; PRAGMA EXCEPTION_INIT(e_four_eyes,-20040);

  -- Create a PENDING version for an existing key. Returns the version id.
  FUNCTION add_version (
    p_ssi_key_id   IN NUMBER,
    p_valid_from   IN DATE,
    p_valid_to     IN DATE,
    p_direction    IN VARCHAR2,
    p_source_ref   IN VARCHAR2,
    p_change_req   IN NUMBER,
    p_user         IN VARCHAR2
  ) RETURN NUMBER;

  -- Checker approves: overlap check under lock, then supersede and activate.
  PROCEDURE approve_version (p_ssi_version_id IN NUMBER, p_checker IN VARCHAR2);

  PROCEDURE reject_version (p_ssi_version_id IN NUMBER, p_checker IN VARCHAR2, p_reason IN VARCHAR2);

  -- Resolve the SSI version to use. Raises e_ambiguous on a tie and
  -- e_not_found when nothing matches. Never guesses.
  FUNCTION resolve (
    p_tenant_id     IN NUMBER,
    p_account_id    IN NUMBER,
    p_country       IN VARCHAR2,
    p_security_type IN VARCHAR2,
    p_method        IN VARCHAR2,
    p_payment_type  IN VARCHAR2,
    p_currency      IN VARCHAR2,
    p_direction     IN VARCHAR2,
    p_business_date IN DATE
  ) RETURN NUMBER;

END ssi_pkg;
/

CREATE OR REPLACE PACKAGE BODY ssi_pkg AS

  c_far CONSTANT DATE := DATE '9999-12-31';

  PROCEDURE lock_key (p_ssi_key_id IN NUMBER) IS
    l_id NUMBER;
  BEGIN
    SELECT ssi_key_id INTO l_id FROM ssi_key WHERE ssi_key_id = p_ssi_key_id FOR UPDATE;
  END lock_key;

  FUNCTION add_version (
    p_ssi_key_id IN NUMBER, p_valid_from IN DATE, p_valid_to IN DATE, p_direction IN VARCHAR2,
    p_source_ref IN VARCHAR2, p_change_req IN NUMBER, p_user IN VARCHAR2
  ) RETURN NUMBER IS
    l_next NUMBER;
    l_id   NUMBER;
  BEGIN
    lock_key(p_ssi_key_id);
    SELECT NVL(MAX(version_no), 0) + 1 INTO l_next FROM ssi_version WHERE ssi_key_id = p_ssi_key_id;
    INSERT INTO ssi_version (ssi_key_id, version_no, valid_from, valid_to, status,
                             permitted_direction, source_reference, change_request_id, created_by)
    VALUES (p_ssi_key_id, l_next, p_valid_from, p_valid_to, 'PENDING',
            NVL(p_direction, 'BOTH'), p_source_ref, p_change_req, p_user)
    RETURNING ssi_version_id INTO l_id;
    RETURN l_id;
  END add_version;

  PROCEDURE approve_version (p_ssi_version_id IN NUMBER, p_checker IN VARCHAR2) IS
    v       ssi_version%ROWTYPE;
    l_clash NUMBER;
  BEGIN
    SELECT * INTO v FROM ssi_version WHERE ssi_version_id = p_ssi_version_id;
    IF v.created_by = p_checker THEN
      RAISE_APPLICATION_ERROR(-20040, 'Maker cannot approve their own change');
    END IF;
    lock_key(v.ssi_key_id);

    -- An open-ended ACTIVE version that starts earlier is closed at the new
    -- start date (normal replacement). Anything else that overlaps is an error.
    UPDATE ssi_version
       SET valid_to = v.valid_from
     WHERE ssi_key_id = v.ssi_key_id AND status = 'ACTIVE'
       AND valid_to IS NULL AND valid_from < v.valid_from;

    SELECT COUNT(*) INTO l_clash FROM ssi_version
     WHERE ssi_key_id = v.ssi_key_id AND status = 'ACTIVE'
       AND ssi_version_id <> v.ssi_version_id
       AND v.valid_from < NVL(valid_to, c_far)
       AND NVL(v.valid_to, c_far) > valid_from;
    IF l_clash > 0 THEN
      RAISE_APPLICATION_ERROR(-20010, 'Overlapping active SSI for this key and period');
    END IF;

    -- A closed predecessor becomes SUPERSEDED once it ends at the new start
    UPDATE ssi_version SET status = 'SUPERSEDED'
     WHERE ssi_key_id = v.ssi_key_id AND status = 'ACTIVE'
       AND valid_to = v.valid_from AND ssi_version_id <> v.ssi_version_id;

    UPDATE ssi_version
       SET status = 'ACTIVE', approved_by = p_checker, approved_at = SYSTIMESTAMP
     WHERE ssi_version_id = v.ssi_version_id;

    UPDATE change_request
       SET status = 'APPROVED', checker_id = p_checker, checker_at = SYSTIMESTAMP
     WHERE change_request_id = v.change_request_id;
  END approve_version;

  PROCEDURE reject_version (p_ssi_version_id IN NUMBER, p_checker IN VARCHAR2, p_reason IN VARCHAR2) IS
    l_cr NUMBER;
  BEGIN
    UPDATE ssi_version SET status = 'REJECTED'
     WHERE ssi_version_id = p_ssi_version_id AND status = 'PENDING'
    RETURNING change_request_id INTO l_cr;
    UPDATE change_request
       SET status = 'REJECTED', checker_id = p_checker, checker_at = SYSTIMESTAMP, comments = p_reason
     WHERE change_request_id = l_cr;
  END reject_version;

  FUNCTION resolve (
    p_tenant_id IN NUMBER, p_account_id IN NUMBER, p_country IN VARCHAR2, p_security_type IN VARCHAR2,
    p_method IN VARCHAR2, p_payment_type IN VARCHAR2, p_currency IN VARCHAR2, p_direction IN VARCHAR2,
    p_business_date IN DATE
  ) RETURN NUMBER IS
    l_fund   NUMBER;
    l_client NUMBER;
    l_best   NUMBER;
    l_score1 NUMBER;
    l_score2 NUMBER;
    l_id2    NUMBER;
    CURSOR c_cand IS
      WITH sec_tree AS (                      -- requested type, then the type it rolls up to
        SELECT security_type_code, LEVEL AS depth
          FROM ref_security_type
         START WITH security_type_code = p_security_type
       CONNECT BY PRIOR rolls_up_to = security_type_code
      )
      SELECT v.ssi_version_id,
             CASE k.scope_level WHEN 'ACCOUNT' THEN 300 WHEN 'FUND' THEN 200 ELSE 100 END
           + (50 - t.depth * 10)
           + CASE WHEN k.payment_type = p_payment_type THEN 5 ELSE 0 END
           + CASE WHEN k.currency_code IS NOT NULL THEN 2 ELSE 0 END AS score
        FROM ssi_key k
        JOIN ssi_version v           ON v.ssi_key_id = k.ssi_key_id
        JOIN ref_market_combination m ON m.combination_id = k.combination_id
        JOIN sec_tree t              ON t.security_type_code = m.security_type_code
       WHERE k.tenant_id    = p_tenant_id
         AND m.country_code = p_country
         AND m.method_code  = p_method
         AND m.status       = 'ACTIVE'
         AND k.payment_type IN (p_payment_type, 'ANY')
         AND (k.currency_code = p_currency OR k.currency_code IS NULL)
         AND (k.account_id = p_account_id OR k.fund_id = l_fund OR k.client_id = l_client)
         AND v.status = 'ACTIVE'
         AND p_business_date >= v.valid_from
         AND (v.valid_to IS NULL OR p_business_date < v.valid_to)
         AND (v.permitted_direction = 'BOTH'
              OR (v.permitted_direction = 'DELIVER_ONLY' AND p_direction = 'DELIVER')
              OR (v.permitted_direction = 'RECEIVE_ONLY' AND p_direction = 'RECEIVE'))
       ORDER BY score DESC;
  BEGIN
    SELECT a.fund_id, f.client_id INTO l_fund, l_client
      FROM account a JOIN fund f ON f.fund_id = a.fund_id
     WHERE a.account_id = p_account_id;

    OPEN c_cand;
    FETCH c_cand INTO l_best, l_score1;
    IF c_cand%NOTFOUND THEN
      CLOSE c_cand;
      RAISE_APPLICATION_ERROR(-20030, 'No active SSI for '||p_country||'-'||p_security_type||'-'||p_method);
    END IF;
    FETCH c_cand INTO l_id2, l_score2;      -- second-best candidate
    IF c_cand%FOUND AND l_score2 = l_score1 THEN
      CLOSE c_cand;
      RAISE_APPLICATION_ERROR(-20020, 'Ambiguous SSI: two candidates share the top score');
    END IF;
    CLOSE c_cand;
    RETURN l_best;
  END resolve;

END ssi_pkg;
/
